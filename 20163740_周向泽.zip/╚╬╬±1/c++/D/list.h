#pragma once
#include<iostream>
#include<string>
#include<stdlib.h>
using namespace std;
struct xinxi
{
public:
	int no,data;
	xinxi *next;
};
class list
{
public:
	list(void);
	~list(void);
	xinxi * createList();
	xinxi * insertno(int n, xinxi * head);
	xinxi * findno(int n, xinxi * head);
	xinxi * deleteno(int n, xinxi * head);
	xinxi * traverse(xinxi * head);
};


