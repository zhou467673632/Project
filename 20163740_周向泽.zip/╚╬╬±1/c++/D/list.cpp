#include "list.h"
#
using namespace std;
list::list(void)
{
	
}


list::~list(void)
{
	
}
xinxi * list::createList()
{
	xinxi *ps=NULL;
	xinxi *pEnd=NULL;
	xinxi *pHead=NULL;

	ps=new xinxi;
	ps->no=1;

	while(ps->no!=0)
	{
		cout<<"��������";
		cin>>ps->data;
		if(pHead == NULL)
			pHead=ps; 		
		else
			pEnd->next=ps;
           pEnd=ps;
		ps=new xinxi;		
		cin>>ps->no;
	}
	pEnd->next=NULL;
	delete ps;
	return pHead;
}
xinxi * list::insertno(int n, xinxi * head)
{
  xinxi *curxinxi = head;// ָ������ĺ�ڵ�
  xinxi *prexinxi = NULL;// ָ�������ǰ�ڵ�
  xinxi *newxinxi = NULL;// ָ���½��ڵ�
  while ((curxinxi!=NULL)&&(curxinxi->no<n)) 
  {
    prexinxi = curxinxi; // ��ڵ��Ϊǰ�ڵ�
    curxinxi = curxinxi->next; 
  }
  newxinxi = new xinxi ;  
  if (newxinxi == NULL) 
  {
    cout << "No memory available!";
	  return head;	
  }
    newxinxi->no = n;
	cout<<"��������";
	cin>>newxinxi->data;
  if (prexinxi == NULL) //���뵽����ͷ
  {
    newxinxi->next = curxinxi; 
    return newxinxi; 
  }
  else  
  {
    prexinxi->next = newxinxi; 
    newxinxi->next = curxinxi; 
    return head; 
  }
}
xinxi * list::findno(int n, xinxi * head)
{
  xinxi *curxinxi = head;
  while ( curxinxi )  
  {
     if ( curxinxi->no == n)  
	 {
	   cout<<curxinxi->no<<" "<<curxinxi->data<<endl;
       return curxinxi;
     }
     curxinxi = curxinxi->next;
  }
  cout<<"Can't find "<<n<<" in the list."<<endl;
  return NULL;
} 
xinxi * list::deleteno(int n, xinxi * head)
{
  xinxi *curxinxi = head;
  xinxi *prexinxi = NULL;
 while (curxinxi && curxinxi->no != n) 
  {
    prexinxi = curxinxi; 
    curxinxi = curxinxi->next; 
  }
  if (curxinxi == NULL) 
  {
    cout<<"Can't find "<<n<<" in the list"<<endl;
    return head;
  }
  if (prexinxi == NULL) 
    head = head->next; 
  else
    prexinxi->next = curxinxi->next; 
  delete curxinxi;
  return head;	
} 
xinxi * list::traverse(xinxi * head)
{
	xinxi *ps=head;
	while(ps!=NULL&&ps->no!=0)
	{cout<<ps->no<<" "<<ps->data<<endl;
	ps=ps->next;
	}
	delete ps;
	return NULL;
}